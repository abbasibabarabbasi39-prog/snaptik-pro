import express from "express";
import dotenv from "dotenv";
import { fal } from "@fal-ai/client";
import { rateLimit } from "express-rate-limit";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const MODEL = "fal-ai/wan-25-preview/text-to-video";

if (!process.env.FAL_KEY) {
  console.error("Missing FAL_KEY. Add it as an environment variable.");
  process.exit(1);
}

fal.config({ credentials: process.env.FAL_KEY });

app.set("trust proxy", 1);
app.use(express.json({ limit: "20kb" }));
app.use(express.static("public"));

const generationLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 5,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many generation requests. Please try again later." }
});

app.post("/api/generate", generationLimit, async (req, res) => {
  try {
    const { prompt, aspectRatio = "16:9", duration = "5", resolution = "720p" } = req.body ?? {};

    if (typeof prompt !== "string" || prompt.trim().length < 5 || prompt.trim().length > 1500) {
      return res.status(400).json({ error: "Prompt must be between 5 and 1500 characters." });
    }
    if (!["16:9", "9:16", "1:1"].includes(aspectRatio)) {
      return res.status(400).json({ error: "Invalid aspect ratio." });
    }
    if (!["5", "10"].includes(String(duration))) {
      return res.status(400).json({ error: "Duration must be 5 or 10 seconds." });
    }
    if (!["480p", "720p", "1080p"].includes(resolution)) {
      return res.status(400).json({ error: "Invalid resolution." });
    }

    const submitted = await fal.queue.submit(MODEL, {
      input: {
        prompt: prompt.trim(),
        aspect_ratio: aspectRatio,
        duration: String(duration),
        resolution,
        enable_prompt_expansion: true,
        enable_safety_checker: true
      }
    });

    res.json({ requestId: submitted.request_id });
  } catch (error) {
    console.error("Submit error:", error);
    res.status(500).json({ error: "Could not submit video job. Check your fal.ai account and API key." });
  }
});

app.get("/api/status/:requestId", async (req, res) => {
  try {
    const requestId = req.params.requestId;
    if (!/^[a-zA-Z0-9-]{10,100}$/.test(requestId)) {
      return res.status(400).json({ error: "Invalid request ID." });
    }

    const status = await fal.queue.status(MODEL, {
      requestId,
      logs: false
    });

    if (status.status === "COMPLETED") {
      const result = await fal.queue.result(MODEL, { requestId });
      const videoUrl = result.data?.video?.url;
      if (!videoUrl) {
        return res.status(502).json({ error: "The model completed but did not return a video URL." });
      }
      return res.json({
        status: "COMPLETED",
        videoUrl,
        actualPrompt: result.data?.actual_prompt ?? null
      });
    }

    res.json({ status: status.status });
  } catch (error) {
    console.error("Status error:", error);
    res.status(500).json({ error: "Could not check generation status." });
  }
});

app.get("/health", (_req, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log(`SnapTik Pro is running on port ${PORT}`);
});
